PUBG GREEN SCANNER PRO
طريقة البناء عبر GitHub Actions من الهاتف:

1) أنشئ Repository جديداً في GitHub باسم PUBG-GREEN-SCANNER-PRO.
2) ارفع محتويات هذا المجلد إلى جذر المستودع (لا ترفع ملف ZIP نفسه).
3) افتح تبويب Actions في المستودع.
4) اختر Build PUBG GREEN SCANNER PRO APK ثم Run workflow إذا لم يبدأ تلقائياً.
5) بعد نجاح البناء افتح تشغيل Workflow ثم نزّل Artifact باسم PUBG-GREEN-SCANNER-PRO-APK.
6) فك ضغط Artifact لتحصل على app-debug.apk.

تنبيه: التطبيق واجهة تجريبية فقط. لا يتصل بخوادم PUBG ولا يجلب بيانات حسابات حقيقية.
