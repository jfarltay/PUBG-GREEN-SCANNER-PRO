package com.green.pubgscanner;
import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(4,9,6), PANEL=Color.rgb(12,24,16);
    private final int GREEN=Color.rgb(57,255,117), MUTED=Color.rgb(150,180,157);
    private boolean arabic=false;
    private EditText idInput;
    private LinearLayout root, historyBox;
    private TextView status;
    private final ArrayList<String> history=new ArrayList<>();

    private GradientDrawable shape(int color,int border) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color);
        d.setCornerRadius(22); d.setStroke(1,border); return d;
    }
    private TextView text(String s,int size,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
        return t;
    }
    private LinearLayout panel() {
        LinearLayout p=new LinearLayout(this); p.setOrientation(1);
        p.setPadding(16,16,16,16); p.setBackground(shape(PANEL,0xff18552f)); return p;
    }
    private void gap(LinearLayout p,int h) {
        View v=new View(this); p.addView(v,new LinearLayout.LayoutParams(1,h));
    }
    @Override public void onCreate(Bundle b) { super.onCreate(b); draw(); }

    private void draw() {
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        ScrollView scroll=new ScrollView(this);
        root=new LinearLayout(this); root.setOrientation(1);
        root.setPadding(20,20,20,28); root.setBackgroundColor(BG);
        scroll.addView(root); setContentView(scroll);

        LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(text("PUBG GREEN SCANNER",18,GREEN,true),
            new LinearLayout.LayoutParams(0,-2,1));
        TextView lang=text(arabic?"العربية | EN":"EN | العربية",13,GREEN,true);
        lang.setPadding(12,10,12,10); lang.setBackground(shape(PANEL,GREEN));
        lang.setOnClickListener(v->{arabic=!arabic;draw();}); header.addView(lang);
        root.addView(header);

        TextView sub=text("PRO PLAYER LOOKUP  •  MATRIX INTERFACE",10,MUTED,true);
        sub.setPadding(0,12,0,22); root.addView(sub);
        LinearLayout sys=panel(); sys.addView(text("● SYSTEM READY",14,GREEN,true));
        gap(sys,7); sys.addView(text("LOCAL APP / VERSION 1.0",10,MUTED,false));
        root.addView(sys);

        TextView label=text(arabic?"معرّف اللاعب (Player ID)":"PLAYER ID",12,GREEN,true);
        label.setPadding(2,22,2,9); root.addView(label);
        idInput=new EditText(this); idInput.setSingleLine(true);
        idInput.setTextColor(Color.WHITE); idInput.setHintTextColor(MUTED);
        idInput.setHint(arabic?"أدخل رقم اللاعب هنا":"Enter PUBG Player ID");
        idInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        idInput.setTextSize(15); idInput.setPadding(16,12,16,12);
        idInput.setBackground(shape(PANEL,0xff1c6034));
        root.addView(idInput,new LinearLayout.LayoutParams(-1,58));

        TextView note=text(arabic?
          "هذه نسخة تجريبية تحفظ المعرّفات محلياً ولا تتصل بخوادم PUBG.":
          "Demo build: validates and stores IDs locally; no PUBG server connection.",10,MUTED,false);
        note.setPadding(2,10,2,14); root.addView(note);

        TextView go=text(arabic?"بدء البحث  →":"START LOOKUP  →",14,BG,true);
        go.setGravity(Gravity.CENTER); go.setPadding(12,16,12,16);
        go.setBackground(shape(GREEN,GREEN)); go.setOnClickListener(v->lookup());
        root.addView(go);

        status=text(arabic?"الحالة: جاهز":"STATUS: READY",11,GREEN,true);
        status.setPadding(2,20,2,12); root.addView(status);

        LinearLayout results=panel();
        results.addView(text(arabic?"نتائج البحث":"LOOKUP RESULTS",13,GREEN,true));
        gap(results,10);
        results.addView(text(arabic?
          "لا توجد نتائج. يلزم مصدر API رسمي أو مصرح به لعرض بيانات حقيقية.":
          "No results yet. An authorized data API is required for real player data.",11,MUTED,false));
        root.addView(results);

        TextView hist=text(arabic?"سجل البحث":"RECENT LOOKUPS",12,GREEN,true);
        hist.setPadding(2,22,2,10); root.addView(hist);
        historyBox=panel(); root.addView(historyBox); refreshHistory();
        TextView footer=text("PUBG GREEN SCANNER PRO",9,MUTED,true);
        footer.setGravity(Gravity.CENTER); footer.setPadding(0,24,0,0); root.addView(footer);
    }
    private void lookup() {
        String id=idInput.getText().toString().trim();
        if(id.length()<5) {
            status.setText(arabic?"خطأ: أدخل Player ID صحيحاً":"ERROR: Enter a valid Player ID");
            return;
        }
        if(!history.contains(id)) history.add(0,id);
        while(history.size()>8) history.remove(history.size()-1);
        status.setText(arabic?"تم حفظ المعرّف محلياً":"ID SAVED LOCALLY");
        refreshHistory();
        new AlertDialog.Builder(this)
          .setTitle(arabic?"مصدر البيانات غير مربوط":"DATA PROVIDER NOT CONNECTED")
          .setMessage(arabic?
            "تم حفظ المعرّف في سجل الهاتف. هذه النسخة لا تتصل بخوادم PUBG ولا تكشف بيانات الحسابات.":
            "The ID was saved locally. This build is not connected to PUBG servers and does not retrieve account information.")
          .setPositiveButton(arabic?"حسناً":"OK",null).show();
    }
    private void refreshHistory() {
        historyBox.removeAllViews();
        if(history.isEmpty()) historyBox.addView(text(arabic?"لا توجد عمليات بحث محفوظة":"No lookup history yet",11,MUTED,false));
        else for(String id:history) historyBox.addView(text("›  "+id,12,Color.WHITE,false));
    }
}
